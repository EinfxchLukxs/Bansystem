package me.yourname.banplugin;

import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.Date;

public class BanCommand implements CommandExecutor {

    private final BanPlugin plugin;

    public BanCommand(BanPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("banplugin.ban")) {
            sender.sendMessage(ChatColor.RED + "[Cubeworld] Keine Berechtigung.");
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "[Cubeworld] Benutzung: /ban <Spieler> <Grund>");
            return true;
        }

        String target = args[0];
        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));

        Bukkit.getBanList(BanList.Type.NAME).addBan(target, reason, null, sender.getName());

        Player banned = Bukkit.getPlayerExact(target);
        if (banned != null) {
            banned.kickPlayer("[Cubeworld] Du wurdest gebannt: " + reason);
        }

        Bukkit.broadcastMessage(ChatColor.RED + "[Cubeworld] " + target + " wurde gebannt: " + reason);
        return true;
    }
}
