# BanPlugin

Ein einfaches Minecraft Ban Plugin für Spigot mit Cubeworld-Prefix.

## Features

- `/ban <Spieler> <Grund>`: Bannt einen Spieler mit Grund.
- Kickt den Spieler sofort.
- Speichert Bann in der Server-Banlist.
- Alle Nachrichten beginnen mit dem Prefix **[Cubeworld]**.

## Installation

1. Kompiliere das Plugin mit Maven oder direkt als `.jar`.
2. Lege die `.jar`-Datei in den `plugins/` Ordner deines Servers.
3. Starte den Server neu.

## Rechte

- `banplugin.ban` – Erlaubt das Bannen von Spielern (Standard: OP)

## Lizenz

MIT
