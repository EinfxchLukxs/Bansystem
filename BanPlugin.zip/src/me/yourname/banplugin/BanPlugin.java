package me.yourname.banplugin;

import org.bukkit.plugin.java.JavaPlugin;

public class BanPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getCommand("ban").setExecutor(new BanCommand(this));
        getLogger().info("BanPlugin aktiviert.");
    }

    @Override
    public void onDisable() {
        getLogger().info("BanPlugin deaktiviert.");
    }
}
